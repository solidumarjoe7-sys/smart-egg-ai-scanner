import React, { useState, useEffect } from 'react';
import { Camera, Cpu, Calendar, Clock, BarChart3, Moon, Sun, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import Scanner from './components/Scanner';
import AdminPanel from './components/AdminPanel';
import HatchCalculator from './components/HatchCalculator';
import HistoryPanel from './components/HistoryPanel';
import Analytics from './components/Analytics';
import { ScanResult, DatasetItem, TrainingLog } from './types';

// Preloaded records so the user sees a pristine, ready-to-test dashboard environment immediately!
const INITIAL_DATASET: DatasetItem[] = [
  {
    id: 'pt_1',
    imageUrl: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=600&q=80',
    label: 'Day 5',
    stageDay: 5,
    status: 'Healthy Embryo',
    approved: true,
    timestamp: Date.now() - 500000000,
    isUserContributed: false
  },
  {
    id: 'pt_2',
    imageUrl: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=600&q=80',
    label: 'Day 14',
    stageDay: 14,
    status: 'Healthy Embryo',
    approved: true,
    timestamp: Date.now() - 400000000,
    isUserContributed: false
  },
  {
    id: 'pt_3',
    imageUrl: 'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=600&q=80',
    label: 'Infertile Egg',
    stageDay: 0,
    status: 'Infertile Egg',
    approved: true,
    timestamp: Date.now() - 300000000,
    isUserContributed: false
  },
  {
    id: 'pt_4',
    imageUrl: 'https://images.unsplash.com/photo-1553531384-cc64ac80f931?auto=format&fit=crop&w=600&q=80',
    label: 'Dead Embryo',
    stageDay: 0,
    status: 'Dead Embryo',
    approved: true,
    timestamp: Date.now() - 200000000,
    isUserContributed: false
  },
  // User contributed pending list
  {
    id: 'pt_user_1',
    imageUrl: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=600&q=80',
    label: 'Day 7',
    stageDay: 7,
    status: 'Healthy Embryo',
    approved: false, // Pending admin approval
    timestamp: Date.now() - 50000000,
    isUserContributed: true
  },
  {
    id: 'pt_user_2',
    imageUrl: 'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=600&q=80',
    label: 'Infertile Egg',
    stageDay: 0,
    status: 'Infertile Egg',
    approved: false, // Pending admin approval
    timestamp: Date.now() - 10000000,
    isUserContributed: true
  }
];

const INITIAL_SCANS: ScanResult[] = [
  {
    id: 'scan_init_1',
    imageUrl: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=600&q=80',
    timestamp: Date.now() - 3600000 * 24 * 3, // 3 days ago
    ageDays: 5,
    ageWeeks: 0,
    status: 'Healthy Embryo',
    confidence: 96.5,
    description: 'Vivid "spider form" detected with clear vitelline vascular branching spreading across upper yolk hemisphere. Active embryonic optic center is visible.',
    notes: 'Incubator Unit A, Row 3'
  },
  {
    id: 'scan_init_2',
    imageUrl: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=600&q=80',
    timestamp: Date.now() - 3600000 * 24 * 1.5, // 1.5 days ago
    ageDays: 14,
    ageWeeks: 2,
    status: 'Healthy Embryo',
    confidence: 98.2,
    description: 'Substantial dark central embryo mass filling close to 70% of inner layout. Large air pocket cell borders are remarkably sharp and clear.',
    notes: 'Incubator Unit B, Row 12'
  },
  {
    id: 'scan_init_3',
    imageUrl: 'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=600&q=80',
    timestamp: Date.now() - 3600000 * 4, // 4 hours ago
    ageDays: 0,
    ageWeeks: 0,
    status: 'Infertile Egg',
    confidence: 99.1,
    description: 'Clear pristine orange-yellow glow throughout entire interior. Complete absence of any vascular ring or dark embryo spot. Recommend immediate disposal.',
    notes: 'Incubator Unit A, Row 5'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'scan' | 'admin' | 'calculator' | 'history' | 'analytics'>('scan');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [scans, setScans] = useState<ScanResult[]>(() => {
    const saved = localStorage.getItem('smart_egg_scans');
    return saved ? JSON.parse(saved) : INITIAL_SCANS;
  });
  const [dataset, setDataset] = useState<DatasetItem[]>(() => {
    const saved = localStorage.getItem('smart_egg_dataset');
    return saved ? JSON.parse(saved) : INITIAL_DATASET;
  });
  const [customLabels, setCustomLabels] = useState<string[]>(() => {
    const saved = localStorage.getItem('smart_egg_labels');
    return saved ? JSON.parse(saved) : [
      'Day 1', 'Day 3', 'Day 5', 'Day 7', 'Day 10', 'Day 14', 'Day 18', 'Day 21', 'Infertile Egg', 'Dead Embryo'
    ];
  });
  const [isModelTrained, setIsModelTrained] = useState<boolean>(() => {
    return localStorage.getItem('smart_egg_trained') === 'true';
  });

  // Persist state changes in localStorage for clean offline experience
  useEffect(() => {
    localStorage.setItem('smart_egg_scans', JSON.stringify(scans));
  }, [scans]);

  useEffect(() => {
    localStorage.setItem('smart_egg_dataset', JSON.stringify(dataset));
  }, [dataset]);

  useEffect(() => {
    localStorage.setItem('smart_egg_labels', JSON.stringify(customLabels));
  }, [customLabels]);

  // Scan lifecycle triggers
  const handleAddNewScan = (newScan: ScanResult) => {
    setScans(prev => [newScan, ...prev]);
  };

  const handleDeleteScan = (id: string) => {
    setScans(prev => prev.filter(s => s.id !== id));
  };

  const handleContributeUserScan = (scan: ScanResult) => {
    const stageDay = scan.ageDays;
    
    const newItem: DatasetItem = {
      id: 'contributed_' + Date.now(),
      imageUrl: scan.imageUrl,
      label: scan.status === 'Healthy Embryo' ? `Day ${stageDay}` : scan.status,
      stageDay,
      status: scan.status,
      approved: false, // Needs admin moderation review
      timestamp: Date.now(),
      isUserContributed: true
    };
    
    setDataset(prev => [newItem, ...prev]);
  };

  // Dataset item moderators
  const handleAddDatasetItem = (item: DatasetItem) => {
    setDataset(prev => [item, ...prev]);
  };

  const handleApproveItem = (id: string) => {
    setDataset(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, approved: true };
      }
      return item;
    }));
  };

  const handleDeleteDatasetItem = (id: string) => {
    setDataset(prev => prev.filter(item => item.id !== id));
  };

  // Custom label actions
  const handleAddLabel = (label: string) => {
    setCustomLabels(prev => [...prev, label]);
  };

  const handleDeleteLabel = (label: string) => {
    setCustomLabels(prev => prev.filter(l => l !== label));
  };

  const handleTrainingCompletedState = (logs: TrainingLog[]) => {
    setIsModelTrained(true);
    localStorage.setItem('smart_egg_trained', 'true');
  };

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="bg-[#F9FAFB] dark:bg-zinc-950 min-h-screen text-slate-900 dark:text-zinc-50 font-sans transition-colors duration-300 flex flex-col md:flex-row overflow-x-hidden">
        
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden md:flex w-64 bg-white dark:bg-zinc-900 border-r border-slate-200 dark:border-zinc-800 flex-col h-screen sticky top-0 shrink-0">
          <div className="p-6 flex items-center space-x-3 border-b border-slate-100 dark:border-zinc-800/50">
            <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-amber-500/20 text-xl font-bold">
              🥚
            </div>
            <div>
              <span className="font-sans font-black text-sm tracking-tight text-slate-800 dark:text-zinc-100 block">Smart Egg</span>
              <span className="text-[10px] font-bold tracking-widest uppercase text-amber-500 block leading-none">AI Scanner</span>
            </div>
          </div>
          
          <nav className="flex-1 px-4 space-y-1.5 mt-6">
            <button
              onClick={() => setActiveTab('scan')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === 'scan'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 font-bold'
                  : 'text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800/40 hover:text-slate-900 dark:hover:text-zinc-200'
              }`}
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span>Scanner Panel</span>
            </button>

            <button
              onClick={() => setActiveTab('calculator')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === 'calculator'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 font-bold'
                  : 'text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800/40 hover:text-slate-900 dark:hover:text-zinc-200'
              }`}
            >
              <Calendar className="w-4 h-4 shrink-0" />
              <span>Hatch Predictor</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 font-bold'
                  : 'text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800/40 hover:text-slate-900 dark:hover:text-zinc-200'
              }`}
            >
              <Clock className="w-4 h-4 shrink-0" />
              <span>Scan Library</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 font-bold'
                  : 'text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800/40 hover:text-slate-900 dark:hover:text-zinc-200'
              }`}
            >
              <BarChart3 className="w-4 h-4 shrink-0" />
              <span>Analytics Hub</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-400 font-bold'
                  : 'text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800/40 hover:text-slate-900 dark:hover:text-zinc-200'
              }`}
            >
              <Cpu className="w-4 h-4 shrink-0" />
              <span>Neural Training</span>
            </button>
          </nav>

          <div className="p-4 mt-auto">
            <div className="bg-slate-905 bg-slate-900 dark:bg-zinc-950/50 rounded-xl p-4 text-white text-xs border border-transparent dark:border-zinc-800">
              <p className="opacity-70 text-[9px] uppercase tracking-wider font-bold">Active Engine</p>
              <p className="font-bold text-sm mt-1 text-slate-100">Poultry-v2.4-Gold</p>
              <div className="mt-3 bg-slate-800 h-1 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-400 h-full transition-all duration-700" 
                  style={{ width: isModelTrained ? '99.8%' : '96.2%' }}
                />
              </div>
              <p className="mt-2 text-emerald-400 font-bold flex items-center justify-between">
                <span>{isModelTrained ? '99.8% Accuracy' : '96.2% Accuracy'}</span>
                <span className="text-[8px] tracking-wide text-zinc-400 font-mono">STABLE</span>
              </p>
            </div>
          </div>
        </aside>

        {/* Mobile top sticky header */}
        <header className="md:hidden sticky top-0 z-40 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-slate-200 dark:border-zinc-805 h-16 flex items-center justify-between px-4">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center text-white shadow text-sm font-bold">
              🥚
            </div>
            <div>
              <span className="font-sans font-black text-xs text-slate-800 dark:text-zinc-100 block">Smart Egg</span>
              <span className="text-[8px] font-black tracking-widest uppercase text-amber-550 block">AI Scanner</span>
            </div>
          </div>
          
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-1.5 text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800 border border-slate-200 dark:border-zinc-800 rounded-lg transition-all"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </header>

        {/* Desktop and Tablet Main Content Window */}
        <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
          
          {/* Main Top Header */}
          <header className="hidden md:flex h-20 bg-white dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 px-8 items-center justify-between shrink-0">
            <div>
              <h1 className="text-xl font-bold font-sans tracking-tight text-slate-800 dark:text-zinc-100 uppercase">
                {activeTab === 'scan' && "AI Scanner Terminal"}
                {activeTab === 'calculator' && "Poultry Hatch Predictor"}
                {activeTab === 'history' && "Historical Diagnostic Library"}
                {activeTab === 'analytics' && "Diagnostic Analytics Hub"}
                {activeTab === 'admin' && "Neural Network Training Matrix"}
              </h1>
              <p className="text-xs text-slate-400 dark:text-zinc-500 uppercase tracking-wider font-semibold mt-0.5">
                {activeTab === 'scan' && `Ready for analysis • Station #04`}
                {activeTab === 'calculator' && `Dynamic baseline calibration active`}
                {activeTab === 'history' && `Archived candling telemetry records`}
                {activeTab === 'analytics' && `Performance index benchmarks`}
                {activeTab === 'admin' && "Adam Optimizer Loss Mitigation Core"}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 text-slate-500 dark:text-zinc-400 hover:bg-slate-50 dark:hover:bg-zinc-800 border border-slate-200 dark:border-zinc-800 rounded-xl transition-all"
                title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {darkMode ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
              </button>
              
              <div className="flex items-center space-x-2 border-l border-slate-200 dark:border-zinc-800 pl-4">
                <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-955 text-amber-800 dark:text-amber-100 text-[10px] font-black flex items-center justify-center border border-amber-300 dark:border-amber-80 *">
                  SG
                </div>
                <div className="text-left hidden lg:block">
                  <p className="text-xs font-bold text-slate-800 dark:text-zinc-200 leading-none">Marjoe S.</p>
                  <p className="text-[8px] font-semibold text-slate-400 uppercase tracking-widest mt-0.5">Hatchery Chief</p>
                </div>
              </div>
            </div>
          </header>

          {/* Tab content Stage Wrapper */}
          <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto pb-24 md:pb-8">
            
            {activeTab === 'scan' && (
              <Scanner 
                onScanCompleted={handleAddNewScan}
                datasetSize={dataset.filter(item => item.approved).length}
                customLabels={customLabels}
                isModelTrained={isModelTrained}
              />
            )}

            {activeTab === 'admin' && (
              <AdminPanel
                dataset={dataset}
                onAddDatasetItem={handleAddDatasetItem}
                onApproveItem={handleApproveItem}
                onDeleteItem={handleDeleteDatasetItem}
                onTrainingCompleted={handleTrainingCompletedState}
                customLabels={customLabels}
                onAddCustomLabel={handleAddLabel}
                onDeleteCustomLabel={handleDeleteLabel}
              />
            )}

            {activeTab === 'calculator' && (
              <HatchCalculator />
            )}

            {activeTab === 'history' && (
              <HistoryPanel
                scans={scans}
                onDeleteScan={handleDeleteScan}
                onContributeToDataset={handleContributeUserScan}
              />
            )}

            {activeTab === 'analytics' && (
              <Analytics scans={scans} />
            )}

          </main>

          {/* Desktop Footer Status Bar */}
          <footer className="hidden md:flex h-10 bg-white dark:bg-zinc-900 border-t border-slate-200 dark:border-zinc-800 px-8 items-center justify-between text-[10px] font-bold text-slate-400 dark:text-zinc-500 tracking-wider shrink-0 uppercase">
            <div className="flex items-center space-x-6">
              <span className="flex items-center">
                <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-pulse"></span>
                SYSTEM STABLE
              </span>
              <span>LATENCY: 42MS</span>
              <span>AI ENGINE: WEB_ENV_TENSORFLOW.JS_V4</span>
            </div>
            <div>
              &copy; 2026 SMART EGG POULTRY AI GROUP • V4.0.2
            </div>
          </footer>

        </div>

        {/* Mobile viewport bottom sticky navigation tab bar */}
        <footer className="block md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-zinc-900/95 border-t border-slate-200 dark:border-zinc-800 backdrop-blur-md z-45 pb-safe">
          <div className="grid grid-cols-5 h-16 items-center text-center">
            
            <button
              onClick={() => setActiveTab('scan')}
              className={`flex flex-col items-center justify-center h-full gap-1 transition-all ${
                activeTab === 'scan' ? 'text-amber-600 font-extrabold' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <Camera className="w-5 h-5" />
              <span className="text-[9px] font-bold">Scan</span>
            </button>

            <button
              onClick={() => setActiveTab('calculator')}
              className={`flex flex-col items-center justify-center h-full gap-1 transition-all ${
                activeTab === 'calculator' ? 'text-amber-600' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span className="text-[9px] font-bold">Hatch</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex flex-col items-center justify-center h-full gap-1 transition-all ${
                activeTab === 'history' ? 'text-amber-600' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <Clock className="w-5 h-5" />
              <span className="text-[9px] font-bold">History</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex flex-col items-center justify-center h-full gap-1 transition-all ${
                activeTab === 'analytics' ? 'text-amber-600' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-[9px] font-bold">Analytics</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex flex-col items-center justify-center h-full gap-1 transition-all ${
                activeTab === 'admin' ? 'text-indigo-600 font-extrabold' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <Cpu className="w-5 h-5" />
              <span className="text-[9px] font-bold">Train</span>
            </button>

          </div>
        </footer>

      </div>
    </div>
  );
}
