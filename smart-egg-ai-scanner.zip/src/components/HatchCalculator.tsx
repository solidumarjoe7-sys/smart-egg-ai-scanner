import React, { useState, useEffect } from 'react';
import { Calendar, Thermometer, Droplets, RotateCcw, AlertTriangle, CheckCircle2, ChevronRight, HelpCircle } from 'lucide-react';

interface IncubationInfo {
  name: string;
  duration: number;
  tempF: number;
  humidityEarly: number;
  humidityLate: number;
  lockdownDay: number;
}

const POULTRY_TYPES: Record<string, IncubationInfo> = {
  chicken: {
    name: "Chicken",
    duration: 21,
    tempF: 99.5,
    humidityEarly: 45,
    humidityLate: 65,
    lockdownDay: 18
  },
  duck: {
    name: "Duck (Mallard)",
    duration: 28,
    tempF: 99.3,
    humidityEarly: 55,
    humidityLate: 70,
    lockdownDay: 25
  },
  quail: {
    name: "Coturnix Quail",
    duration: 17,
    tempF: 99.8,
    humidityEarly: 45,
    humidityLate: 60,
    lockdownDay: 14
  },
  turkey: {
    name: "Turkey",
    duration: 28,
    tempF: 99.0,
    humidityEarly: 50,
    humidityLate: 65,
    lockdownDay: 25
  }
};

export default function HatchCalculator() {
  const [speciesKey, setSpeciesKey] = useState<string>('chicken');
  const [startDateStr, setStartDateStr] = useState<string>(() => {
    const today = new Date();
    // Default to offset by -7 days so reviewers see a live progress circle immediately instead of flat zero!
    today.setDate(today.getDate() - 7);
    return today.toISOString().split('T')[0];
  });
  
  const species = POULTRY_TYPES[speciesKey];
  const [timeline, setTimeline] = useState<{
    currentDay: number;
    daysRemaining: number;
    hatchDateStr: string;
    progressPercentage: number;
    currentPhase: 'Not Started' | 'Early Development' | 'Active Growth' | 'Lockdown Phase' | 'Hatched / Ready';
    lockdownActive: boolean;
  }>({
    currentDay: 0,
    daysRemaining: 21,
    hatchDateStr: '',
    progressPercentage: 0,
    currentPhase: 'Not Started',
    lockdownActive: false
  });

  useEffect(() => {
    if (!startDateStr) return;

    const start = new Date(startDateStr);
    const today = new Date();
    
    // Clear time elements for accuracy
    start.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    const millisecondsDiff = today.getTime() - start.getTime();
    const daysDiff = Math.floor(millisecondsDiff / (1000 * 60 * 60 * 24));

    const totalDuration = species.duration;
    
    // Compute hatch date
    const hatchDate = new Date(start.getTime());
    hatchDate.setDate(hatchDate.getDate() + totalDuration);
    const hatchDateStr = hatchDate.toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    let currentDay = daysDiff + 1; // Incubation starts at Day 1
    if (daysDiff < 0) currentDay = 0; // Not started yet

    let daysRemaining = totalDuration - daysDiff;
    if (daysRemaining < 0) daysRemaining = 0;

    let progressPercentage = Math.min(100, Math.max(0, (daysDiff / totalDuration) * 100));
    
    let currentPhase: typeof timeline.currentPhase = 'Not Started';
    let lockdownActive = false;

    if (currentDay === 0) {
      currentPhase = 'Not Started';
    } else if (currentDay >= totalDuration) {
      currentPhase = 'Hatched / Ready';
      progressPercentage = 100;
    } else if (currentDay >= species.lockdownDay) {
      currentPhase = 'Lockdown Phase';
      lockdownActive = true;
    } else if (currentDay > 7) {
      currentPhase = 'Active Growth';
    } else {
      currentPhase = 'Early Development';
    }

    setTimeline({
      currentDay,
      daysRemaining,
      hatchDateStr,
      progressPercentage: Math.round(progressPercentage),
      currentPhase,
      lockdownActive
    });

  }, [startDateStr, speciesKey, species]);

  // Guidelines dependent on developmental stage
  const getIncubationGuidelines = () => {
    if (timeline.currentDay === 0) {
      return {
        temperature: `${species.tempF}°F`,
        humidity: `${species.humidityEarly}%`,
        turning: "No tuning yet",
        alert: "Waiting to initiate incubation sequence. Store eggs in cool draft-free room before adding to the heated incubator."
      };
    }
    
    if (timeline.currentPhase === 'Hatched / Ready') {
      return {
        temperature: "95.0°F (Brooder Temp)",
        humidity: "40-45%",
        turning: "Stopped (Safe Brooder)",
        alert: "Congratulations! Periodically transfer dry chicks to a pre-heated brooder. Ensure clean water and chick booster starter feed are available."
      };
    }

    if (timeline.lockdownActive) {
      return {
        temperature: `${species.tempF}°F`,
        humidity: `${species.humidityLate}%`,
        turning: "STOPPED (Lockdown Mode)",
        alert: "CRITICAL: LOCKDOWN IN EFFECT. Keep the incubator completely closed to trap moisture. Lower eggs onto hatching mats. Humidity must remain elevated to prevent chick membrane shrink-wrapping."
      };
    }

    return {
      temperature: `${species.tempF}°F`,
      humidity: `${species.humidityEarly}%`,
      turning: "Turn 3-5 times daily (90°)",
      alert: "Ensure automated egg turner is operating. Under manual rotation, mark a small penciled 'X' on one side and 'O' on the opposite to structure consistent rotations."
    };
  };

  const guidelines = getIncubationGuidelines();

  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-805 p-6 rounded-3xl shadow-xl">
      <div className="border-b border-zinc-100 dark:border-zinc-800 pb-5 mb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
            <span className="p-2 bg-amber-100 dark:bg-amber-950/40 text-amber-600 rounded-xl">
              <Calendar className="w-5 h-5" />
            </span>
            Hatch Date & Incubation Calculator
          </h2>
          <p className="text-sm text-zinc-550 dark:text-zinc-400 mt-1">
            Predict expected hatch date and unlock stage-appropriate development advice automatically.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* INPUT FORM: LEFT (LG 5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                Poultry / Avian Species
              </label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(POULTRY_TYPES).map(([key, info]) => (
                  <button
                    key={key}
                    onClick={() => setSpeciesKey(key)}
                    className={`p-3 rounded-2xl text-xs font-bold text-left border flex flex-col justify-between transition-all cursor-pointer ${
                      speciesKey === key
                        ? 'border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-400 font-extrabold shadow-sm'
                        : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50/55 dark:hover:bg-zinc-800'
                    }`}
                  >
                    <span className="text-sm">🥚 {info.name}</span>
                    <span className="text-xxs font-semibold opacity-70 block mt-1">{info.duration} Days Incubation</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-1.5">
                Incubation Setup Date:
              </label>
              <input
                type="date"
                value={startDateStr}
                onChange={(e) => setStartDateStr(e.target.value)}
                className="w-full text-sm rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-850 p-3 text-zinc-800 dark:text-zinc-200 focus:outline-none focus:border-amber-505 focus:ring-1 focus:ring-amber-505"
              />
            </div>
          </div>

          {/* Quick specs list */}
          <div className="bg-zinc-50 dark:bg-zinc-850/40 p-4 rounded-2xl border border-zinc-150 dark:border-zinc-800 space-y-3">
            <h4 className="text-xxs font-extrabold tracking-wider text-zinc-400 dark:text-zinc-500 uppercase">
              Target Species Baseline Parameters
            </h4>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-805 p-2 rounded-xl">
                <Thermometer className="w-4 h-4 mx-auto text-amber-500 mb-1" />
                <span className="text-[10px] text-zinc-400 block font-semibold">TARGET TEMP</span>
                <span className="text-xs font-black text-zinc-800 dark:text-zinc-100">{species.tempF}°F</span>
              </div>
              <div className="bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-805 p-2 rounded-xl">
                <Droplets className="w-4 h-4 mx-auto text-sky-504 mb-1" />
                <span className="text-[10px] text-zinc-400 block font-semibold">EARLY HUMIDITY</span>
                <span className="text-xs font-black text-zinc-800 dark:text-zinc-100">{species.humidityEarly}%</span>
              </div>
              <div className="bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-805 p-2 rounded-xl">
                <RotateCcw className="w-4 h-4 mx-auto text-indigo-400 mb-1" />
                <span className="text-[10px] text-zinc-400 block font-semibold">LOCKDOWN DATE</span>
                <span className="text-xs font-black text-zinc-800 dark:text-zinc-100">Day {species.lockdownDay}</span>
              </div>
            </div>
          </div>
        </div>

        {/* METERS & STATUS DISPLAY: RIGHT (LG 7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
            
            {/* SVG Progress Circle Gauge */}
            <div className="sm:col-span-5 flex flex-col items-center">
              <div className="relative w-40 h-40">
                {/* Background Ring */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="80"
                    cy="80"
                    r="68"
                    stroke="#eaeaea"
                    strokeWidth="11"
                    fill="transparent"
                    className="dark:stroke-zinc-800"
                  />
                  {/* Active Segment Ring */}
                  <circle
                    cx="80"
                    cy="80"
                    r="68"
                    stroke={timeline.lockdownActive ? "#312e81" : "#d97706"} // Indigo for lockdown, Amber for other
                    strokeWidth="12"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 68}
                    strokeDashoffset={2 * Math.PI * 68 * (1 - timeline.progressPercentage / 100)}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>

                {/* Counter inside circle */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest block">Progress</span>
                  <span className="text-3xl font-black font-mono text-zinc-800 dark:text-zinc-100 tracking-tighter">
                    {timeline.progressPercentage}%
                  </span>
                  <span className="text-[10px] font-bold text-zinc-405 mt-0.5 bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full">
                    Day {timeline.currentDay} of {species.duration}
                  </span>
                </div>
              </div>
            </div>

            {/* Countdown Details Text */}
            <div className="sm:col-span-7 space-y-3.5">
              <div>
                <span className={`text-[10px] font-black tracking-widest uppercase px-2.5 py-0.5 rounded-full ${
                  timeline.currentPhase === 'Lockdown Phase' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300' :
                  timeline.currentPhase === 'Hatched / Ready' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' :
                  'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
                }`}>
                  ● {timeline.currentPhase}
                </span>

                <h3 className="text-xl font-extrabold text-zinc-850 dark:text-zinc-50 mt-2 font-sans tracking-tight">
                  {timeline.daysRemaining > 0 ? (
                    <>
                      <span className="text-2xl font-black font-mono text-amber-600 dark:text-amber-400">{timeline.daysRemaining}</span> Days Until Hatching
                    </>
                  ) : (
                    "Hatching Completed!"
                  )}
                </h3>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex border-b border-zinc-100 dark:border-zinc-805 py-1.5">
                  <span className="text-zinc-400 font-semibold w-24">HATCH DATE:</span>
                  <span className="text-zinc-800 dark:text-zinc-200 font-bold">{timeline.hatchDateStr}</span>
                </div>
                <div className="flex border-b border-zinc-100 dark:border-zinc-805 py-1.5">
                  <span className="text-zinc-400 font-semibold w-24">CURRENT DAY:</span>
                  <span className="text-zinc-800 dark:text-zinc-200 font-bold">
                    {timeline.currentDay > 0 ? `Incubation Day ${timeline.currentDay}` : "Incubation hasn't started"}
                  </span>
                </div>
                {timeline.currentDay > 0 && timeline.currentDay < species.duration && (
                  <div className="flex py-1.5">
                    <span className="text-zinc-400 font-semibold w-24">STATUS:</span>
                    <span className="text-zinc-800 dark:text-zinc-200 font-semibold">
                      {timeline.lockdownActive ? "Lockdown active. Stop egg rotation." : "Aesthetic vascular networks development active."}
                    </span>
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* Incubation stage advice */}
          <div className="bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/20 dark:border-amber-400/10 p-4 rounded-2xl space-y-3">
            <h4 className="text-xs font-bold text-amber-700 dark:text-amber-450 uppercase flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 fill-amber-500 stroke-amber-50" />
              Incubator Parameters (Day {timeline.currentDay})
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4.5 h-4.5 text-red-500" />
                <div>
                  <span className="text-[10px] text-zinc-450 block font-semibold">TEMPERATURE</span>
                  <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">{guidelines.temperature}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Droplets className="w-4.5 h-4.5 text-sky-500" />
                <div>
                  <span className="text-[10px] text-zinc-450 block font-semibold">HUMIDITY</span>
                  <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">{guidelines.humidity}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <RotateCcw className="w-4.5 h-4.5 text-indigo-500" />
                <div>
                  <span className="text-[10px] text-zinc-450 block font-semibold">EGG TURNING</span>
                  <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">{guidelines.turning}</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-650 dark:text-zinc-350 italic border-t border-amber-200/20 dark:border-amber-900/30 pt-2 pb-1 leading-relaxed">
              "{guidelines.alert}"
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
