import React, { useState, useEffect } from 'react';
import { Upload, Plus, Trash2, CheckCircle2, X, Play, Download, Sliders, Database, LineChart, Cpu, BarChart2 } from 'lucide-react';
import { DatasetItem, EggStatus, TrainingLog, DEVELOPMENT_STAGES_INFO } from '../types';

interface AdminPanelProps {
  dataset: DatasetItem[];
  onAddDatasetItem: (item: DatasetItem) => void;
  onApproveItem: (id: string) => void;
  onDeleteItem: (id: string) => void;
  onTrainingCompleted: (logs: TrainingLog[]) => void;
  customLabels: string[];
  onAddCustomLabel: (label: string) => void;
  onDeleteCustomLabel: (label: string) => void;
}

export default function AdminPanel({
  dataset,
  onAddDatasetItem,
  onApproveItem,
  onDeleteItem,
  onTrainingCompleted,
  customLabels,
  onAddCustomLabel,
  onDeleteCustomLabel,
}: AdminPanelProps) {
  // Label states
  const [newLabelInput, setNewLabelInput] = useState('');
  
  // Image upload states
  const [uploadLabel, setUploadLabel] = useState('Day 5');
  const [uploadedBase64, setUploadedBase64] = useState<string | null>(null);

  // Training state
  const [isTraining, setIsTraining] = useState(false);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [totalEpochs, setTotalEpochs] = useState(30);
  const [trainingLogs, setTrainingLogs] = useState<TrainingLog[]>([]);
  const [isTrained, setIsTrained] = useState(false);

  // Handle local label upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setUploadedBase64(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const submitToDataset = () => {
    if (!uploadedBase64) return;
    
    // Parse stage number
    const dayMatch = uploadLabel.match(/Day\s+(\d+)/);
    const stageDay = dayMatch ? parseInt(dayMatch[1]) : 0;
    
    let status: EggStatus = 'Healthy Embryo';
    if (uploadLabel.toLowerCase().includes('infertile')) status = 'Infertile Egg';
    if (uploadLabel.toLowerCase().includes('dead') || uploadLabel.toLowerCase().includes('blood')) status = 'Dead Embryo';

    const newItem: DatasetItem = {
      id: 'data_' + Date.now(),
      imageUrl: uploadedBase64,
      label: uploadLabel,
      stageDay,
      status,
      approved: true, // admin uploads are autoapproved
      timestamp: Date.now(),
      isUserContributed: false
    };

    onAddDatasetItem(newItem);
    setUploadedBase64(null);
  };

  // Mock training loop utilizing classic gradient descent curves
  const startModelTraining = () => {
    setIsTraining(true);
    setCurrentEpoch(0);
    setTrainingLogs([]);
    setIsTrained(false);

    let logsAccumulator: TrainingLog[] = [];
    let epoch = 1;

    const interval = setInterval(() => {
      // Simulate highly realistic SGD loss decrements
      const baseLoss = 0.85 / (1 + epoch * 0.15);
      const loss = parseFloat((baseLoss + Math.random() * 0.04).toFixed(4));
      const valLoss = parseFloat((baseLoss * 1.05 + Math.random() * 0.06).toFixed(4));

      // Simulate ascending accuracy values
      const baseAcc = 0.55 + (0.42 * (epoch / totalEpochs)) * (1.1 - 0.1 * (epoch / totalEpochs));
      const accuracy = parseFloat(Math.min(0.992, baseAcc + Math.random() * 0.02).toFixed(4));
      const valAccuracy = parseFloat(Math.min(0.985, baseAcc * 0.98 + Math.random() * 0.025).toFixed(4));

      const logEntry: TrainingLog = {
        epoch,
        loss,
        valLoss,
        accuracy,
        valAccuracy
      };

      logsAccumulator.push(logEntry);
      setTrainingLogs([...logsAccumulator]);
      setCurrentEpoch(epoch);

      if (epoch >= totalEpochs) {
        clearInterval(interval);
        setIsTraining(false);
        setIsTrained(true);
        onTrainingCompleted(logsAccumulator);
      }
      epoch++;
    }, 150); // Fast enough to be extremely exciting, but readable
  };

  // Download Simulated Teachable Machine bundle (model.json and weights.bin)
  const downloadModelBundle = () => {
    // Generate simulated model.json content
    const modelJson = {
      format: "layers-model",
      generatedBy: "Smart Egg AI Trainer v2.4",
      convertedBy: "TensorFlow.js Converter v4.12.0",
      modelTopology: {
        class_names: customLabels,
        layers: [
          { name: "conv2d_input", type: "Conv2D", shape: [null, 224, 224, 3] },
          { name: "max_pooling2d", type: "MaxPooling2D" },
          { name: "dense_classification", type: "Dense", units: customLabels.length, activation: "softmax" }
        ]
      },
      weightsDescription: [
        { name: "conv2d_weights", shape: [3, 3, 3, 32], dtype: "float32" },
        { name: "dense_weights", shape: [1568, customLabels.length], dtype: "float32" }
      ]
    };

    // Download model JSON file
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(modelJson, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "smart_egg_tfjs_model.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    // Trigger a fake weights download as well to represent full bundle
    setTimeout(() => {
      const b64FakeWeights = "data:application/octet-stream;base64,VEVOU09SRkxPVy5KUyBCSU5BUlkgV0VJR0hUUyAtIFNNQVJULUVHRy1BSS1UUkFJTkVELU1PREVMLUhBVENIRVJZLU1BTkFHRU1FTlQtU1lTVEVNLTIwMjY=";
      const weightsAnchor = document.createElement('a');
      weightsAnchor.setAttribute("href", b64FakeWeights);
      weightsAnchor.setAttribute("download", "smart_egg_tfjs_model.weights.bin");
      document.body.appendChild(weightsAnchor);
      weightsAnchor.click();
      weightsAnchor.remove();
    }, 450);
  };

  // Segment dataset by approved status
  const approvedItems = dataset.filter(item => item.approved);
  const pendingItems = dataset.filter(item => !item.approved);

  // Group approved items by category for statistics
  const countByCategory = (cat: EggStatus) => {
    return approvedItems.filter(item => item.status === cat).length;
  };

  // Simple label addition
  const handleAddLabel = () => {
    if (newLabelInput.trim() && !customLabels.includes(newLabelInput.trim())) {
      onAddCustomLabel(newLabelInput.trim());
      setNewLabelInput('');
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      
      {/* LEFT PANEL: Label maker + Statistic cards (XL: 4 cols) */}
      <div className="xl:col-span-4 space-y-6">
        
        {/* Dataset Dashboard Statistics */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-sm font-extrabold tracking-wider text-zinc-400 dark:text-zinc-500 uppercase flex items-center gap-1.5">
            <Database className="w-4 h-4 text-amber-500" />
            Dataset Distribution
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-zinc-50 dark:bg-zinc-850 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
              <span className="text-xxs text-zinc-400 font-bold block uppercase tracking-wider">Total Labeled</span>
              <span className="text-2xl font-black font-mono text-zinc-800 dark:text-zinc-100">{approvedItems.length}</span>
            </div>
            <div className="bg-zinc-50 dark:bg-zinc-850 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
              <span className="text-xxs text-emerald-600 font-bold block uppercase tracking-wider">Healthy</span>
              <span className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">{countByCategory('Healthy Embryo')}</span>
            </div>
            <div className="bg-zinc-50 dark:bg-zinc-850 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
              <span className="text-xxs text-zinc-500 font-bold block uppercase tracking-wider">Infertile</span>
              <span className="text-2xl font-black font-mono text-zinc-550 dark:text-zinc-400">{countByCategory('Infertile Egg')}</span>
            </div>
            <div className="bg-zinc-50 dark:bg-zinc-850 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
              <span className="text-xxs text-rose-500 font-bold block uppercase tracking-wider">Dead Rings</span>
              <span className="text-2xl font-black font-mono text-rose-600 dark:text-rose-400">{countByCategory('Dead Embryo')}</span>
            </div>
          </div>
        </div>

        {/* Training Labels Setup */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-sm font-extrabold tracking-wider text-zinc-400 dark:text-zinc-500 uppercase flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-indigo-500" />
            Class Labels Manager
          </h3>
          <p className="text-xs text-zinc-400">
            Define classification nodes for Teachable Machine integration. The model optimizes output coordinates for these exact classes.
          </p>

          <div className="flex gap-2">
            <input
              type="text"
              value={newLabelInput}
              onChange={(e) => setNewLabelInput(e.target.value)}
              placeholder="e.g., Day 22, Broken Shell"
              className="flex-1 text-sm rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-850 px-3 py-2 text-zinc-850 dark:text-zinc-100 focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleAddLabel}
              className="p-2 bg-zinc-800 dark:bg-zinc-700 hover:bg-zinc-900 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto pr-1">
            {customLabels.map((lbl) => {
              const isDefault = ['Day 1', 'Day 3', 'Day 5', 'Day 7', 'Day 10', 'Day 14', 'Day 18', 'Day 21', 'Infertile Egg', 'Dead Embryo'].includes(lbl);
              return (
                <div
                  key={lbl}
                  className="flex items-center gap-1 px-2.5 py-1 bg-zinc-50 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-350 text-xs font-semibold rounded-lg border border-zinc-100 dark:border-zinc-800"
                >
                  <span>{lbl}</span>
                  {!isDefault && (
                    <button
                      onClick={() => onDeleteCustomLabel(lbl)}
                      className="text-zinc-400 hover:text-red-500 ml-1 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Dataset Ingestion Module */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-sm font-extrabold tracking-wider text-zinc-400 dark:text-zinc-500 uppercase flex items-center gap-1.5">
            <Upload className="w-4 h-4 text-emerald-500" />
            Ingest Training Image
          </h3>
          <p className="text-xs text-zinc-400">
            Expand the local dataset instantly by cataloging a reference image under a specific development day or status.
          </p>

          <div className="space-y-3">
            <div>
              <label className="block text-xxs font-bold text-zinc-400 uppercase mb-1">Target Class Label</label>
              <select
                value={uploadLabel}
                onChange={(e) => setUploadLabel(e.target.value)}
                className="w-full text-sm rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-850 p-2 text-zinc-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                {customLabels.map((lbl) => (
                  <option key={lbl} value={lbl}>{lbl}</option>
                ))}
              </select>
            </div>

            <div className="border border-dashed border-zinc-200 dark:border-zinc-800 p-3 rounded-2xl flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-850/30">
              {uploadedBase64 ? (
                <div className="text-center">
                  <img src={uploadedBase64} className="w-20 h-20 object-contain mx-auto rounded-lg mb-2 shadow" alt="preview" />
                  <button
                    onClick={() => setUploadedBase64(null)}
                    className="text-xxs text-rose-500 hover:underline cursor-pointer"
                  >
                    Clear Photo
                  </button>
                </div>
              ) : (
                <label className="text-center cursor-pointer p-4 block w-full">
                  <Upload className="w-5 h-5 text-zinc-400 mx-auto mb-1.5" />
                  <span className="text-xs text-zinc-500 hover:text-amber-500 font-semibold block">Select Reference JPEG</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            <button
              onClick={submitToDataset}
              disabled={!uploadedBase64}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow disabled:opacity-50 transition-all cursor-pointer"
            >
              Add to Dataset
            </button>
          </div>
        </div>

      </div>

      {/* RIGHT PANEL: Live Training Loop & Dataset moderations (XL: 8 cols) */}
      <div className="xl:col-span-8 space-y-6">

        {/* Model Training Dashboard */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-6 rounded-3xl space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-100 dark:border-zinc-805 pb-4">
            <div>
              <h3 className="text-lg font-bold text-zinc-905 dark:text-zinc-50 flex items-center gap-2">
                <span className="p-1.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 rounded-xl">
                  <Cpu className="w-5 h-5" />
                </span>
                Teachable Machine Model Optimizer
              </h3>
              <p className="text-xs text-zinc-450 mt-1">
                Train a custom client-side classifier on-device using layers configured with backpropagation.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="text-right hidden sm:block">
                <span className="text-[10px] text-zinc-400 block font-semibold uppercase">Optimizer</span>
                <span className="text-xs font-bold text-zinc-650 dark:text-zinc-350 font-mono">Adam (lr=0.001)</span>
              </div>
              <button
                disabled={isTraining || approvedItems.length < 3}
                onClick={startModelTraining}
                className="px-4 py-2.5 bg-indigo-650 hover:bg-indigo-700 text-white rounded-2xl text-xs font-black shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Optimize Custom Model
              </button>
            </div>
          </div>

          {approvedItems.length < 3 && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/25 border border-amber-100 dark:border-amber-900/30 text-amber-850 dark:text-amber-300 rounded-2xl text-xs flex items-start gap-2">
              <Database className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Insufficient images to segment.</span> You need at least 3 approved reference images in the local database to begin tensor distribution and validation splitting. Click "Add to Dataset" on the left or approve user scans below first.
              </div>
            </div>
          )}

          {/* Real-time Optimizer Graphs */}
          {(trainingLogs.length > 0 || isTraining || isTrained) && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Visual Chart 1: Loss Reduction */}
                <div className="border border-zinc-150 dark:border-zinc-800 p-4 rounded-2xl bg-zinc-50/50 dark:bg-zinc-850/20">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider flex items-center gap-1">
                      <LineChart className="w-4 h-4 text-rose-500" />
                      Loss Curve
                    </span>
                    <span className="text-xxs font-mono text-rose-500 bg-rose-50 dark:bg-rose-950/30 px-1.5 py-0.5 rounded">
                      Loss: {trainingLogs[trainingLogs.length - 1]?.loss}
                    </span>
                  </div>
                  <span className="text-[10px] text-zinc-400 block mb-3">Goal: Minimize divergence error toward zero.</span>

                  {/* SVG line graph for dynamic loss plotting */}
                  <div className="w-full h-40 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-xl relative overflow-hidden flex items-end px-1 pb-1">
                    <svg className="w-full h-full absolute inset-0 pt-4 px-2" viewBox="0 0 100 100" preserveAspectRatio="none">
                      {/* Grid lines */}
                      <line x1="0" y1="25" x2="100" y2="25" stroke="#f4f4f5" strokeWidth="0.5" />
                      <line x1="0" y1="50" x2="100" y2="50" stroke="#f4f4f5" strokeWidth="0.5" />
                      <line x1="0" y1="75" x2="100" y2="75" stroke="#f4f4f5" strokeWidth="0.5" />
                      
                      {/* Loss Line Path */}
                      {trainingLogs.length > 1 && (
                        <polyline
                          fill="none"
                          stroke="#ef4444"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          points={trainingLogs.map((log, index) => {
                            const x = (index / (trainingLogs.length - 1)) * 100;
                            // Loss is compressed to fit standard height
                            const y = Math.max(5, 95 - (log.loss / 1.0) * 80);
                            return `${x},${y}`;
                          }).join(' ')}
                        />
                      )}

                      {/* Val Loss Line Path */}
                      {trainingLogs.length > 1 && (
                        <polyline
                          fill="none"
                          stroke="#f43f5e"
                          strokeWidth="1.5"
                          strokeDasharray="3,3"
                          points={trainingLogs.map((log, index) => {
                            const x = (index / (trainingLogs.length - 1)) * 100;
                            const y = Math.max(5, 95 - (log.valLoss / 1.0) * 80);
                            return `${x},${y}`;
                          }).join(' ')}
                        />
                      )}
                    </svg>
                    <div className="absolute bottom-2 left-2 text-[8px] font-mono text-zinc-400">Epoch 1</div>
                    <div className="absolute bottom-2 right-2 text-[8px] font-mono text-zinc-400">Epoch {currentEpoch}</div>
                  </div>
                  <div className="flex gap-4 mt-2 justify-center text-[10px]">
                    <span className="flex items-center gap-1 font-semibold text-rose-500">
                      <span className="w-2.5 h-0.5 bg-rose-500 inline-block" /> Training Loss
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-rose-400">
                      <span className="w-2.5 h-0.5 bg-rose-400 border-dashed border inline-block" /> Validation Loss
                    </span>
                  </div>
                </div>

                {/* Visual Chart 2: Accuracy Accretion */}
                <div className="border border-zinc-150 dark:border-zinc-800 p-4 rounded-2xl bg-zinc-50/50 dark:bg-zinc-850/20">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider flex items-center gap-1">
                      <BarChart2 className="w-4 h-4 text-emerald-500" />
                      Accuracy Curve
                    </span>
                    <span className="text-xxs font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-1.5 py-0.5 rounded">
                      Acc: {Math.round((trainingLogs[trainingLogs.length - 1]?.accuracy || 0) * 100)}%
                    </span>
                  </div>
                  <span className="text-[10px] text-zinc-400 block mb-3">Goal: Maximize correct predictions toward 100%.</span>

                  {/* SVG line graph for dynamic accuracy plotting */}
                  <div className="w-full h-40 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-xl relative overflow-hidden flex items-end px-1 pb-1">
                    <svg className="w-full h-full absolute inset-0 pt-4 px-2" viewBox="0 0 100 100" preserveAspectRatio="none">
                      {/* Grid lines */}
                      <line x1="0" y1="25" x2="100" y2="25" stroke="#f4f4f5" strokeWidth="0.5" />
                      <line x1="0" y1="50" x2="100" y2="50" stroke="#f4f4f5" strokeWidth="0.5" />
                      <line x1="0" y1="75" x2="100" y2="75" stroke="#f4f4f5" strokeWidth="0.5" />
                      
                      {/* Accuracy Line Path */}
                      {trainingLogs.length > 1 && (
                        <polyline
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          points={trainingLogs.map((log, index) => {
                            const x = (index / (trainingLogs.length - 1)) * 100;
                            // Accuracy typically goes from 0.4 to 1.0
                            const y = 95 - ((log.accuracy - 0.4) / 0.6) * 80;
                            return `${x},${y}`;
                          }).join(' ')}
                        />
                      )}

                      {/* Val Accuracy Line Path */}
                      {trainingLogs.length > 1 && (
                        <polyline
                          fill="none"
                          stroke="#34d399"
                          strokeWidth="1.5"
                          strokeDasharray="3,3"
                          points={trainingLogs.map((log, index) => {
                            const x = (index / (trainingLogs.length - 1)) * 100;
                            const y = 95 - ((log.valAccuracy - 0.4) / 0.6) * 80;
                            return `${x},${y}`;
                          }).join(' ')}
                        />
                      )}
                    </svg>
                    <div className="absolute bottom-2 left-2 text-[8px] font-mono text-zinc-400">Epoch 1</div>
                    <div className="absolute bottom-2 right-2 text-[8px] font-mono text-zinc-400">Epoch {currentEpoch}</div>
                  </div>
                  <div className="flex gap-4 mt-2 justify-center text-[10px]">
                    <span className="flex items-center gap-1 font-semibold text-emerald-600">
                      <span className="w-2.5 h-0.5 bg-emerald-500 inline-block" /> Training Accuracy
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-emerald-400">
                      <span className="w-2.5 h-0.5 bg-emerald-400 border-dashed border inline-block" /> Validation Accuracy
                    </span>
                  </div>
                </div>

              </div>

              {/* Training Progress Bar Details */}
              <div className="bg-zinc-50 dark:bg-zinc-800 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-sm text-zinc-800 dark:text-zinc-150">
                    {isTraining ? `Optimizing Backpropagation Nodes... (Epoch ${currentEpoch}/${totalEpochs})` : "✓ Neural Weights Successfully Saved!"}
                  </div>
                  <p className="text-xs text-zinc-450 mt-0.5">
                    Target shape weights matched to local canvas feature vectors. On-device analysis latency will be &lt;40ms.
                  </p>
                </div>

                {isTrained && (
                  <button
                    onClick={downloadModelBundle}
                    className="px-4 py-2 bg-emerald-650 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow transition-all self-start md:self-auto"
                  >
                    <Download className="w-4 h-4" />
                    Download TFJS Model Bundle (.zip)
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Dataset Expansion: Moderation Inbox for Contributed images */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-md font-bold text-zinc-850 dark:text-zinc-50 flex items-center gap-1.5">
                <Database className="w-4.5 h-4.5 text-amber-500" />
                Dataset Moderation Inbox
              </h3>
              <p className="text-xs text-zinc-450 mt-1">
                Scanned images marked for upload expand our commercial poultry dataset and assist in future automated retraining.
              </p>
            </div>
            <span className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-400 text-xxs font-extrabold rounded-lg">
              {pendingItems.length} PENDING REVIEW
            </span>
          </div>

          {pendingItems.length === 0 ? (
            <div className="text-center py-6 border border-dashed border-zinc-150 dark:border-zinc-800 rounded-3xl">
              <CheckCircle2 className="w-8 h-8 text-emerald-550 mx-auto mb-2 opacity-60" />
              <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">Moderation queue completely cleared.</p>
              <p className="text-[10px] text-zinc-400 mt-1">When users submit scans for dataset expansion, they appear here for verification.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
              {pendingItems.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 bg-zinc-50 dark:bg-zinc-850 border border-zinc-150 dark:border-zinc-800 p-3 rounded-2xl relative"
                >
                  <img
                    src={item.imageUrl}
                    className="w-16 h-16 rounded-xl object-cover bg-zinc-300 shadow-sm border border-zinc-200 dark:border-zinc-800 shrink-0"
                    alt="Pending upload"
                  />
                  <div className="flex flex-col justify-between py-0.5">
                    <div>
                      <span className="text-[10px] font-bold text-indigo-650 dark:text-indigo-400 block tracking-wide uppercase">
                        SUGGESTED LABEL:
                      </span>
                      <span className="text-xs font-extrabold text-zinc-800 dark:text-zinc-100">{item.label}</span>
                      <span className="text-[9px] text-zinc-400 block mt-0.5">
                        Uploaded {new Date(item.timestamp).toLocaleDateString()}
                      </span>
                    </div>

                    <div className="flex gap-2 mt-1 sm:mt-0">
                      <button
                        onClick={() => onApproveItem(item.id)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold rounded-lg shadow-sm flex items-center gap-1 transition-all cursor-pointer"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => onDeleteItem(item.id)}
                        className="px-2 py-1 bg-zinc-200 dark:bg-zinc-800 hover:bg-red-500 hover:text-white dark:hover:bg-red-950 text-zinc-600 dark:text-zinc-400 text-[10px] font-extrabold rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                      >
                        Discard
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Global Dataset Explorer */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-6 rounded-3xl space-y-4">
          <h3 className="text-md font-bold text-zinc-850 dark:text-zinc-50">
            Registered Reference Dataset ({approvedItems.length} Images)
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 max-h-96 overflow-y-auto pr-1 pb-2">
            {approvedItems.map((item) => (
              <div
                key={item.id}
                className="group relative aspect-square bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden hover:shadow-md transition-all flex flex-col justify-between"
              >
                <img src={item.imageUrl} className="w-full h-full object-cover" alt={item.label} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent flex flex-col justify-end p-2 opacity-100 transition-opacity">
                  <span className="text-[9px] font-black text-white truncate block">{item.label}</span>
                  <span className={`text-[7px] px-1 font-bold rounded ${
                    item.status === 'Healthy Embryo' ? 'bg-emerald-500 text-white' :
                    item.status === 'Infertile Egg' ? 'bg-zinc-500 text-white' : 'bg-red-500 text-white'
                  } w-max mt-0.5`}>
                    {item.status.split(' ')[0]}
                  </span>
                </div>
                
                {/* Trash delete from dataset absolute option inside admin */}
                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="absolute top-1.5 right-1.5 p-1 bg-red-650 hover:bg-red-700 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow cursor-pointer"
                  title="Remove from dataset"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
