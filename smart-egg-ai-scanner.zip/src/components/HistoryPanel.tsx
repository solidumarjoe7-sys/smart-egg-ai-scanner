import React, { useState } from 'react';
import { Clock, Trash2, Calendar, Share2, PlusCircle, Database, CheckCircle, ArrowRight } from 'lucide-react';
import { ScanResult } from '../types';

interface HistoryPanelProps {
  scans: ScanResult[];
  onDeleteScan: (id: string) => void;
  onContributeToDataset: (scan: ScanResult) => void;
}

export default function HistoryPanel({ scans, onDeleteScan, onContributeToDataset }: HistoryPanelProps) {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedScan, setSelectedScan] = useState<ScanResult | null>(null);

  const filteredScans = scans.filter(scan => {
    if (filterStatus === 'all') return true;
    return scan.status.toLowerCase() === filterStatus.toLowerCase();
  });

  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-805 p-6 rounded-3xl shadow-xl">
      
      <div className="border-b border-zinc-100 dark:border-zinc-805 pb-5 mb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-zinc-900 dark:text-zinc-50 flex items-center gap-2">
            <span className="p-2 bg-amber-100 dark:bg-amber-950/40 text-amber-600 rounded-xl">
              <Clock className="w-5 h-5" />
            </span>
            Hatchery Scan History
          </h2>
          <p className="text-sm text-zinc-550 dark:text-zinc-400 mt-1">
            Browse previous real-time AI scans, compare historical viability dates, and expand active dataset models.
          </p>
        </div>

        {/* Filter chips */}
        <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-2xl self-start md:self-auto">
          {['All', 'Healthy', 'Infertile', 'Dead'].map((filter) => {
            const key = filter === 'Healthy' ? 'Healthy Embryo' : filter === 'Infertile' ? 'Infertile Egg' : filter === 'Dead' ? 'Dead Embryo' : 'all';
            return (
              <button
                key={filter}
                onClick={() => setFilterStatus(key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  filterStatus === key
                    ? 'bg-white dark:bg-zinc-700 text-amber-600 dark:text-amber-400 shadow-sm font-bold'
                    : 'text-zinc-600 dark:text-zinc-450 hover:text-zinc-900'
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>
      </div>

      {scans.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-zinc-100 dark:border-zinc-800 rounded-3xl">
          <Clock className="w-10 h-10 text-zinc-350 mx-auto mb-3" />
          <p className="text-sm font-semibold text-zinc-500 dark:text-zinc-450">No scans recorded yet.</p>
          <p className="text-xs text-zinc-400 mt-1">Select the main Scan tab, capture an egg candling visual, and click Analyze.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* SCANS LIST: LEFT (LG 5 cols) */}
          <div className="lg:col-span-5 space-y-3 max-h-[500px] overflow-y-auto pr-2">
            {filteredScans.map((scan) => (
              <button
                key={scan.id}
                onClick={() => setSelectedScan(scan)}
                className={`w-full text-left p-3.5 rounded-2xl border transition-all flex gap-3 cursor-pointer ${
                  selectedScan?.id === scan.id
                    ? 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-400 shadow-sm'
                    : 'border-zinc-150 dark:border-zinc-800 bg-zinc-50/40 dark:bg-zinc-850/15 hover:border-zinc-300 dark:hover:border-zinc-700'
                }`}
              >
                <img
                  src={scan.imageUrl}
                  className="w-14 h-14 rounded-xl object-cover bg-zinc-350 shadow-sm border border-zinc-200 dark:border-zinc-800 shrink-0"
                  alt="Historic Scan"
                />
                
                <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                  <div className="flex justify-between items-start">
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                      scan.status === 'Healthy Embryo' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-400' :
                      scan.status === 'Infertile Egg' ? 'bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-400' : 
                      'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-400'
                    }`}>
                      {scan.status}
                    </span>
                    <span className="text-[9px] text-zinc-400 font-semibold font-mono">
                      {new Date(scan.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="flex justify-between items-end mt-1">
                    <div>
                      <span className="text-xs font-bold text-zinc-800 dark:text-zinc-150 block truncate">
                        {scan.ageDays > 0 ? `Estimated Age: Day ${scan.ageDays}` : 'Inviable Egg'}
                      </span>
                      <span className="text-[10px] text-zinc-400 font-semibold flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(scan.timestamp).toLocaleDateString()}
                      </span>
                    </div>

                    <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest bg-amber-500/10 px-1.5 py-0.5 rounded">
                      {scan.confidence}% Acc
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* CHOSEN SCAN DETAIL: RIGHT (LG 7 cols) */}
          <div className="lg:col-span-7">
            {selectedScan ? (
              <div className="border border-zinc-150 dark:border-zinc-800 p-5 rounded-3xl bg-zinc-50/20 dark:bg-zinc-900/40 space-y-5 animate-fade-in">
                
                <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-805 pb-4">
                  <div>
                    <h3 className="text-sm font-extrabold tracking-wider text-zinc-450 uppercase">Analysis Certificate</h3>
                    <span className="text-[10px] text-zinc-400 font-mono">ID: {selectedScan.id}</span>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => onDeleteScan(selectedScan.id)}
                      className="p-2 text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-100 bg-white dark:bg-zinc-800 border border-zinc-250 dark:border-zinc-850 rounded-xl transition-all cursor-pointer"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center">
                  <div className="aspect-[4/3] bg-zinc-950 rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800 shadow">
                    <img src={selectedScan.imageUrl} className="w-full h-full object-cover" alt="" />
                  </div>

                  <div className="space-y-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Egg Development Status</span>
                      <div className={`text-md font-black ${
                        selectedScan.status === 'Healthy Embryo' ? 'text-emerald-600 dark:text-emerald-400' :
                        selectedScan.status === 'Infertile Egg' ? 'text-zinc-600 dark:text-zinc-400' : 'text-rose-600 dark:text-rose-400'
                      }`}>
                        {selectedScan.status}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Embryonic Incubation Day</span>
                      <div className="text-md font-black text-zinc-850 dark:text-zinc-100">
                        {selectedScan.ageDays > 0 ? `${selectedScan.ageDays} Days` : 'Inviable'}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Incubator Coordinate</span>
                      <div className="text-xs font-semibold text-zinc-650 dark:text-zinc-350 truncate">
                        {selectedScan.notes || "Not specified"}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Model opinion */}
                <div className="bg-white dark:bg-zinc-850 border border-zinc-150 dark:border-zinc-800 p-4 rounded-2xl relative">
                  <span className="absolute top-3 right-4 text-xxs font-mono text-zinc-400">CONFIDENCE: {selectedScan.confidence}%</span>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">AI Perception Diagnostics</label>
                  <p className="text-xs text-zinc-700 dark:text-zinc-300 italic leading-relaxed">
                    "{selectedScan.description}"
                  </p>
                </div>

                {/* Dataset contribution button ( rubrics: Dataset Expansion) */}
                {!selectedScan.addedToDataset ? (
                  <button
                    onClick={() => {
                      onContributeToDataset(selectedScan);
                      // mutate locally to avoid multi uploads
                      selectedScan.addedToDataset = true;
                    }}
                    className="w-full py-2.5 border border-dashed border-indigo-250 dark:border-indigo-850 bg-indigo-50/30 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-400 hover:border-indigo-450 hover:bg-indigo-50/60 dark:hover:bg-indigo-950/40 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <PlusCircle className="w-4.5 h-4.5" />
                    Contribute Image & Labels to AI Training Dataset
                  </button>
                ) : (
                  <div className="w-full py-2.5 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle className="w-4.5 h-4.5 text-emerald-500" />
                    <span>✓ Uploaded to Admin Dataset for Moderation</span>
                  </div>
                )}

              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 border border-zinc-100 dark:border-zinc-800 rounded-3xl bg-zinc-50/20">
                <Clock className="w-8 h-8 text-zinc-300 mb-2" />
                <h3 className="text-xs font-bold text-zinc-450 uppercase">Analysis Board</h3>
                <p className="text-[11px] text-zinc-400 mt-1 max-w-xs">Select a historical scan from the left listing viewport to inspect vascular branching diagnostics and add labels.</p>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
