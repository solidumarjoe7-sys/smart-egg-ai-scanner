export type EggStatus = 'Healthy Embryo' | 'Infertile Egg' | 'Dead Embryo';

export interface StageInfo {
  day: number; // 1 to 21 (or 0 for special stages)
  label: string;
  category: EggStatus;
  description: string;
}

export interface ScanResult {
  id: string;
  imageUrl: string;
  timestamp: number;
  ageDays: number;
  ageWeeks: number;
  status: EggStatus;
  confidence: number;
  description: string;
  notes?: string;
  addedToDataset?: boolean;
}

export interface DatasetItem {
  id: string;
  imageUrl: string;
  label: string; // e.g., "Day 7", "Infertile Egg"
  stageDay: number; // 0 for infertile/dead, 1-21 for days
  status: EggStatus;
  approved: boolean;
  timestamp: number;
  isUserContributed: boolean;
}

export interface TrainingLog {
  epoch: number;
  loss: number;
  valLoss: number;
  accuracy: number;
  valAccuracy: number;
}

export interface HatchCountdown {
  startDate: string; // YYYY-MM-DD
  eggType: 'Chicken' | 'Duck' | 'Quail' | 'Turkey';
  hatchDurationDays: number; // 21 for chicken
}

// Global default reference information for the 21 days of egg candling development
export const DEVELOPMENT_STAGES_INFO: Record<string, StageInfo> = {
  'infertile': {
    day: 0,
    label: 'Infertile Egg',
    category: 'Infertile Egg',
    description: 'Completely clear interior when candled. Light passes through unobstructed. No vascular development (spider veins) or dark embryo spot is visible.'
  },
  'dead': {
    day: 0,
    label: 'Dead Embryo',
    category: 'Dead Embryo',
    description: 'Presence of a distinct blood ring (a dark reddish ring circling the inside of the shell) or a spot that remains fixed or settled to the bottom. Disrupted veins.'
  },
  'day1': {
    day: 1,
    label: 'Day 1',
    category: 'Healthy Embryo',
    description: 'Slight thickening of the germinal disc. No visible embryo or veins yet, egg looks mostly clear but yolk center might look slightly denser under strong light.'
  },
  'day3': {
    day: 3,
    label: 'Day 3',
    category: 'Healthy Embryo',
    description: 'The heartbeat begins. Very faint blood vessels (vitelline circulation) begin radiating outward from the blastoderm, looking like tiny red thin fingers.'
  },
  'day5': {
    day: 5,
    label: 'Day 5',
    category: 'Healthy Embryo',
    description: 'Prominent "spider" appearance. The dark central spot (embryo eye) is easily visible, surrounded by well-defined radiating thin blood veins.'
  },
  'day7': {
    day: 7,
    label: 'Day 7',
    category: 'Healthy Embryo',
    description: 'Embryo eye is large and dark, easily visible. Blood veins are thick and branch throughout the top half of the egg. Embryo may twitch slightly.'
  },
  'day10': {
    day: 10,
    label: 'Day 10',
    category: 'Healthy Embryo',
    description: 'Embryo is growing fast, appearing as a dark mass moving under candling. Blood vessels are dense and cover most of the egg except the bottom tip.'
  },
  'day14': {
    day: 14,
    label: 'Day 14',
    category: 'Healthy Embryo',
    description: 'Embryo is quite large. Head is positioned towards the large end of the egg. The air cell at the blunt end of the egg is growing and has a sharp, clear border.'
  },
  'day18': {
    day: 18,
    label: 'Day 18',
    category: 'Healthy Embryo',
    description: 'Egg is almost completely opaque (dark inside) except for the well-defined large air cell at the top. Embryo is taking up the remaining space completely.'
  },
  'day21': {
    day: 21,
    label: 'Day 21 (Hatching)',
    category: 'Healthy Embryo',
    description: 'Egg is fully dark. Piping or tapping sounds may be heard. The air cell border may look uneven as the chick begins internal pipping (breaking inner membrane).'
  }
};
